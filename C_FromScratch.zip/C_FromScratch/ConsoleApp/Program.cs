﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// Mensaje sin salto de linea
Console.Write("Mensaje sin salto de linea");

Console.WriteLine("");
int edad = 21;
Console.WriteLine("Tu edad es " + edad);
Console.WriteLine("Tu edad es :{0}", edad);

// Cadenas
string nombre = "Juan";
Console.WriteLine($"Tu nombre es: {nombre} y tu edad es {edad}");